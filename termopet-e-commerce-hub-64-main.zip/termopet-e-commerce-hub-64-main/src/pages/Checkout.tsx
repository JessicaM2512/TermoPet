import { useState } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { Helmet } from "react-helmet-async";
import { 
  ChevronRight, 
  CreditCard, 
  QrCode, 
  FileText,
  Truck,
  Shield,
  Check
} from "lucide-react";
import { cn } from "@/lib/utils";

const Checkout = () => {
  const { items, totalPrice } = useCart();
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState("pix");

  const shipping = totalPrice >= 199 ? 0 : 19.90;
  const total = totalPrice + shipping;

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Seu carrinho está vazio</h1>
            <Button asChild>
              <Link to="/produtos">Ver produtos</Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Checkout | Termopet</title>
        <meta name="description" content="Finalize sua compra na Termopet" />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-muted/30">
        <Header />
        <CartDrawer />

        <main className="flex-1 py-8">
          <div className="container">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
              <Link to="/" className="hover:text-foreground transition-colors">
                Início
              </Link>
              <ChevronRight className="h-4 w-4" />
              <Link to="/produtos" className="hover:text-foreground transition-colors">
                Carrinho
              </Link>
              <ChevronRight className="h-4 w-4" />
              <span className="text-foreground">Checkout</span>
            </nav>

            {/* Progress */}
            <div className="flex items-center justify-center gap-4 mb-10">
              {[
                { num: 1, label: "Dados" },
                { num: 2, label: "Entrega" },
                { num: 3, label: "Pagamento" },
              ].map((s, i) => (
                <div key={s.num} className="flex items-center">
                  <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all",
                    step >= s.num 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted text-muted-foreground"
                  )}>
                    {step > s.num ? <Check className="h-5 w-5" /> : s.num}
                  </div>
                  <span className={cn(
                    "ml-2 text-sm font-medium hidden sm:block",
                    step >= s.num ? "text-foreground" : "text-muted-foreground"
                  )}>
                    {s.label}
                  </span>
                  {i < 2 && (
                    <div className={cn(
                      "w-16 h-0.5 mx-4",
                      step > s.num ? "bg-primary" : "bg-muted"
                    )} />
                  )}
                </div>
              ))}
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Form */}
              <div className="lg:col-span-2 space-y-6">
                {step === 1 && (
                  <div className="bg-card rounded-2xl p-6 shadow-card animate-fade-in">
                    <h2 className="text-xl font-bold font-display mb-6">Seus Dados</h2>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Nome completo</label>
                        <input
                          type="text"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="Seu nome"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Email</label>
                        <input
                          type="email"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="seu@email.com"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">CPF</label>
                        <input
                          type="text"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="000.000.000-00"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Telefone</label>
                        <input
                          type="tel"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="(00) 00000-0000"
                        />
                      </div>
                    </div>
                    <Button variant="hero" size="lg" className="w-full mt-6" onClick={() => setStep(2)}>
                      Continuar para Entrega
                    </Button>
                  </div>
                )}

                {step === 2 && (
                  <div className="bg-card rounded-2xl p-6 shadow-card animate-fade-in">
                    <h2 className="text-xl font-bold font-display mb-6">Endereço de Entrega</h2>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="sm:col-span-2">
                        <label className="block text-sm font-medium mb-2">CEP</label>
                        <input
                          type="text"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="00000-000"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-sm font-medium mb-2">Endereço</label>
                        <input
                          type="text"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="Rua, Avenida..."
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Número</label>
                        <input
                          type="text"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="123"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Complemento</label>
                        <input
                          type="text"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="Apto, Bloco..."
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Bairro</label>
                        <input
                          type="text"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="Bairro"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Cidade / UF</label>
                        <input
                          type="text"
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          placeholder="São Paulo / SP"
                        />
                      </div>
                    </div>
                    <div className="flex gap-3 mt-6">
                      <Button variant="outline" size="lg" onClick={() => setStep(1)}>
                        Voltar
                      </Button>
                      <Button variant="hero" size="lg" className="flex-1" onClick={() => setStep(3)}>
                        Continuar para Pagamento
                      </Button>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div className="bg-card rounded-2xl p-6 shadow-card animate-fade-in">
                    <h2 className="text-xl font-bold font-display mb-6">Forma de Pagamento</h2>
                    <div className="grid gap-3 mb-6">
                      {[
                        { value: "pix", label: "PIX", desc: "Aprovação imediata", icon: QrCode, discount: "5% de desconto" },
                        { value: "card", label: "Cartão de Crédito", desc: "Até 12x sem juros", icon: CreditCard },
                        { value: "boleto", label: "Boleto Bancário", desc: "Vencimento em 3 dias", icon: FileText },
                      ].map((method) => (
                        <button
                          key={method.value}
                          onClick={() => setPaymentMethod(method.value)}
                          className={cn(
                            "flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-left",
                            paymentMethod === method.value
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/50"
                          )}
                        >
                          <div className={cn(
                            "w-12 h-12 rounded-lg flex items-center justify-center",
                            paymentMethod === method.value ? "bg-primary text-primary-foreground" : "bg-muted"
                          )}>
                            <method.icon className="h-6 w-6" />
                          </div>
                          <div className="flex-1">
                            <p className="font-semibold">{method.label}</p>
                            <p className="text-sm text-muted-foreground">{method.desc}</p>
                          </div>
                          {method.discount && (
                            <span className="px-2 py-1 rounded-full bg-secondary/10 text-secondary text-xs font-medium">
                              {method.discount}
                            </span>
                          )}
                        </button>
                      ))}
                    </div>

                    {paymentMethod === "card" && (
                      <div className="grid sm:grid-cols-2 gap-4 mb-6 p-4 rounded-xl bg-muted/50">
                        <div className="sm:col-span-2">
                          <label className="block text-sm font-medium mb-2">Número do cartão</label>
                          <input
                            type="text"
                            className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                            placeholder="0000 0000 0000 0000"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Validade</label>
                          <input
                            type="text"
                            className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                            placeholder="MM/AA"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">CVV</label>
                          <input
                            type="text"
                            className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                            placeholder="123"
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex gap-3">
                      <Button variant="outline" size="lg" onClick={() => setStep(2)}>
                        Voltar
                      </Button>
                      <Button variant="hero" size="lg" className="flex-1">
                        Finalizar Compra
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {/* Summary */}
              <div>
                <div className="bg-card rounded-2xl p-6 shadow-card sticky top-24">
                  <h3 className="text-lg font-bold font-display mb-4">Resumo do Pedido</h3>
                  
                  <div className="space-y-3 mb-6">
                    {items.map((item) => (
                      <div key={item.id} className="flex gap-3">
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-muted shrink-0">
                          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium line-clamp-1">{item.name}</p>
                          <p className="text-xs text-muted-foreground">Qtd: {item.quantity}</p>
                          <p className="text-sm font-semibold text-primary">
                            R$ {(item.price * item.quantity).toFixed(2).replace(".", ",")}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2 pt-4 border-t border-border">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>R$ {totalPrice.toFixed(2).replace(".", ",")}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Frete</span>
                      <span className={cn(shipping === 0 && "text-secondary font-medium")}>
                        {shipping === 0 ? "Grátis" : `R$ ${shipping.toFixed(2).replace(".", ",")}`}
                      </span>
                    </div>
                    {paymentMethod === "pix" && (
                      <div className="flex justify-between text-sm text-secondary">
                        <span>Desconto PIX (5%)</span>
                        <span>- R$ {(total * 0.05).toFixed(2).replace(".", ",")}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold text-lg pt-2 border-t border-border">
                      <span>Total</span>
                      <span className="text-primary">
                        R$ {(paymentMethod === "pix" ? total * 0.95 : total).toFixed(2).replace(".", ",")}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-4 p-3 rounded-lg bg-secondary/10 text-secondary text-sm">
                    <Shield className="h-4 w-4 shrink-0" />
                    <span>Compra 100% segura</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Checkout;
