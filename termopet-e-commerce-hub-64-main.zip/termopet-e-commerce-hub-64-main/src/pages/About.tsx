import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import { Helmet } from "react-helmet-async";
import { PawPrint, Heart, Shield, Award, Users, Leaf } from "lucide-react";
import heroImage from "@/assets/hero-pet.jpg";

const About = () => {
  return (
    <>
      <Helmet>
        <title>Sobre Nós | Termopet - Conforto Térmico para Pets</title>
        <meta 
          name="description" 
          content="Conheça a Termopet, empresa brasileira especializada em tapetes térmicos para pets. Nossa missão é proporcionar conforto e bem-estar para seu melhor amigo." 
        />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />
        <CartDrawer />

        <main className="flex-1">
          {/* Hero */}
          <section className="relative overflow-hidden bg-gradient-to-br from-background via-accent/30 to-background py-16 lg:py-24">
            <div className="container">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <div>
                  <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                    <Heart className="h-4 w-4" />
                    Nossa História
                  </span>
                  <h1 className="text-4xl lg:text-5xl font-bold font-display mb-6">
                    Cuidando do <span className="text-primary">Conforto</span> do seu Pet
                  </h1>
                  <p className="text-lg text-muted-foreground mb-6">
                    A Termopet nasceu da paixão por animais e da vontade de proporcionar 
                    o melhor conforto térmico para pets em todo o Brasil.
                  </p>
                  <p className="text-muted-foreground">
                    Desde 2018, desenvolvemos tapetes térmicos com tecnologia de ponta, 
                    sem uso de eletricidade, garantindo segurança e bem-estar para 
                    cães e gatos de todos os tamanhos.
                  </p>
                </div>
                <div className="relative">
                  <div className="rounded-3xl overflow-hidden shadow-2xl">
                    <img 
                      src={heroImage} 
                      alt="Pet confortável no tapete Termopet" 
                      className="w-full h-auto"
                    />
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Values */}
          <section className="py-16 lg:py-24 bg-muted/30">
            <div className="container">
              <div className="text-center mb-12">
                <h2 className="text-3xl lg:text-4xl font-bold font-display mb-4">
                  Nossos Valores
                </h2>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Guiamos nossas ações por princípios que colocam o bem-estar animal em primeiro lugar
                </p>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    icon: Heart,
                    title: "Amor pelos Animais",
                    description: "Cada produto é desenvolvido pensando no conforto e felicidade dos pets"
                  },
                  {
                    icon: Shield,
                    title: "Segurança Total",
                    description: "Tecnologia sem eletricidade, garantindo zero riscos para seu pet"
                  },
                  {
                    icon: Award,
                    title: "Qualidade Premium",
                    description: "Materiais de alta qualidade com garantia estendida"
                  },
                  {
                    icon: Users,
                    title: "Atendimento Humano",
                    description: "Suporte personalizado e atencioso para todas as dúvidas"
                  },
                  {
                    icon: Leaf,
                    title: "Sustentabilidade",
                    description: "Compromisso com materiais ecológicos e processos sustentáveis"
                  },
                  {
                    icon: PawPrint,
                    title: "Inovação Constante",
                    description: "Sempre buscando novas tecnologias para o conforto pet"
                  }
                ].map((value, index) => (
                  <div 
                    key={index}
                    className="p-6 rounded-2xl bg-card shadow-card hover:shadow-lg transition-all"
                  >
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <value.icon className="h-7 w-7 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold font-display mb-2">{value.title}</h3>
                    <p className="text-muted-foreground text-sm">{value.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Stats */}
          <section className="py-16 lg:py-24">
            <div className="container">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { value: "+50.000", label: "Pets Felizes" },
                  { value: "6 Anos", label: "de Mercado" },
                  { value: "4.9★", label: "Avaliação Média" },
                  { value: "100%", label: "Satisfação" }
                ].map((stat, index) => (
                  <div key={index} className="text-center p-6 rounded-2xl bg-muted/50">
                    <p className="text-3xl lg:text-4xl font-bold text-primary mb-2">
                      {stat.value}
                    </p>
                    <p className="text-muted-foreground">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default About;
