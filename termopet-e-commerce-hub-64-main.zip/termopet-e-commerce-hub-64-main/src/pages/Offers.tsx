import { products } from "@/data/products";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import ProductCard from "@/components/ProductCard";
import { Helmet } from "react-helmet-async";
import { Clock, Gift, Percent, Truck } from "lucide-react";

const Offers = () => {
  const offerProducts = products.filter((p) => p.isOffer);

  return (
    <>
      <Helmet>
        <title>Ofertas de Dezembro | Termopet - Até 30% OFF</title>
        <meta 
          name="description" 
          content="Aproveite as ofertas especiais de dezembro com até 30% de desconto em tapetes térmicos para pets. Frete grátis!" 
        />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />
        <CartDrawer />

        <main className="flex-1">
          {/* Hero */}
          <section className="relative overflow-hidden bg-gradient-hero py-16 lg:py-24">
            <div className="absolute inset-0 overflow-hidden">
              <div className="absolute -top-40 -right-40 w-80 h-80 bg-background/10 rounded-full blur-3xl" />
              <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-background/10 rounded-full blur-3xl" />
            </div>

            <div className="container relative z-10 text-center">
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-background/20 text-primary-foreground text-sm font-medium mb-6">
                <Gift className="h-4 w-4" />
                Ofertas Especiais
              </span>

              <h1 className="text-4xl lg:text-6xl font-bold font-display text-primary-foreground mb-6">
                Ofertas de Dezembro
              </h1>

              <p className="text-xl text-primary-foreground/80 max-w-2xl mx-auto mb-10">
                Aproveite descontos imperdíveis em toda nossa linha de tapetes térmicos. 
                Seu pet merece o melhor conforto!
              </p>

              {/* Countdown */}
              <div className="flex items-center justify-center gap-4 mb-10">
                <Clock className="h-6 w-6 text-primary-foreground/70" />
                <span className="text-primary-foreground/70">Oferta termina em:</span>
                <div className="flex gap-2">
                  {[
                    { value: "05", label: "dias" },
                    { value: "12", label: "horas" },
                    { value: "36", label: "min" },
                    { value: "24", label: "seg" },
                  ].map((item, index) => (
                    <div key={index} className="bg-background/20 rounded-lg px-4 py-2 text-center min-w-[60px]">
                      <p className="text-2xl font-bold text-primary-foreground">{item.value}</p>
                      <p className="text-xs text-primary-foreground/70">{item.label}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Benefits */}
              <div className="flex flex-wrap items-center justify-center gap-6">
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-background/20">
                  <Percent className="h-5 w-5 text-primary-foreground" />
                  <span className="text-sm text-primary-foreground font-medium">Até 30% OFF</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-background/20">
                  <Truck className="h-5 w-5 text-primary-foreground" />
                  <span className="text-sm text-primary-foreground font-medium">Frete Grátis +R$199</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-background/20">
                  <Gift className="h-5 w-5 text-primary-foreground" />
                  <span className="text-sm text-primary-foreground font-medium">Brindes Exclusivos</span>
                </div>
              </div>
            </div>
          </section>

          {/* Products */}
          <section className="py-16">
            <div className="container">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold font-display mb-4">
                  Produtos em Promoção
                </h2>
                <p className="text-muted-foreground">
                  Corra! Estoque limitado e preços especiais só até o fim de dezembro
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {offerProducts.map((product, index) => (
                  <ProductCard 
                    key={product.id} 
                    product={product}
                    style={{ animationDelay: `${index * 50}ms` } as React.CSSProperties}
                  />
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Offers;
