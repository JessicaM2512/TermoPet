import { useState } from "react";
import { products } from "@/data/products";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Helmet } from "react-helmet-async";
import { Filter, Grid3X3, LayoutList } from "lucide-react";
import { cn } from "@/lib/utils";

const Products = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("featured");

  const categories = [
    { value: "all", label: "Todos" },
    { value: "pequeno", label: "Pequeno" },
    { value: "medio", label: "Médio" },
    { value: "grande", label: "Grande" },
  ];

  const filteredProducts = products.filter((product) => {
    if (selectedCategory === "all") return true;
    return product.category === selectedCategory;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-asc":
        return a.price - b.price;
      case "price-desc":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      default:
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    }
  });

  return (
    <>
      <Helmet>
        <title>Produtos | Termopet - Tapetes Térmicos para Pets</title>
        <meta 
          name="description" 
          content="Conheça nossa linha completa de tapetes térmicos para pets. Diversos tamanhos e modelos para cães e gatos." 
        />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />
        <CartDrawer />

        <main className="flex-1">
          {/* Hero */}
          <section className="bg-gradient-to-br from-background via-accent/30 to-background py-12">
            <div className="container">
              <h1 className="text-3xl lg:text-4xl font-bold font-display mb-2">
                Nossos Produtos
              </h1>
              <p className="text-muted-foreground">
                Encontre o tapete térmico perfeito para seu pet
              </p>
            </div>
          </section>

          {/* Filters */}
          <section className="border-b border-border sticky top-16 bg-background/95 backdrop-blur z-40">
            <div className="container py-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 w-full sm:w-auto">
                  {categories.map((cat) => (
                    <Button
                      key={cat.value}
                      variant={selectedCategory === cat.value ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setSelectedCategory(cat.value)}
                      className={cn(
                        "shrink-0",
                        selectedCategory === cat.value && "shadow-soft"
                      )}
                    >
                      {cat.label}
                    </Button>
                  ))}
                </div>

                <div className="flex items-center gap-3">
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="h-9 px-3 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    <option value="featured">Destaque</option>
                    <option value="price-asc">Menor preço</option>
                    <option value="price-desc">Maior preço</option>
                    <option value="rating">Avaliação</option>
                  </select>
                </div>
              </div>
            </div>
          </section>

          {/* Products Grid */}
          <section className="py-10">
            <div className="container">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sortedProducts.map((product, index) => (
                  <ProductCard 
                    key={product.id} 
                    product={product}
                    style={{ animationDelay: `${index * 50}ms` } as React.CSSProperties}
                  />
                ))}
              </div>

              {sortedProducts.length === 0 && (
                <div className="text-center py-16">
                  <p className="text-muted-foreground">
                    Nenhum produto encontrado nesta categoria.
                  </p>
                </div>
              )}
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Products;
