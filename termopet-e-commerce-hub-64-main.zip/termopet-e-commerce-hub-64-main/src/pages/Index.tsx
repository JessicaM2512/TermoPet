import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import HeroSection from "@/components/HeroSection";
import ProductsSection from "@/components/ProductsSection";
import BenefitsSection from "@/components/BenefitsSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import CtaSection from "@/components/CtaSection";
import { Helmet } from "react-helmet-async";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>Termopet - Tapetes Térmicos para Pets | Conforto e Segurança</title>
        <meta 
          name="description" 
          content="Tapetes térmicos auto-aquecidos para pets. Tecnologia segura sem eletricidade. Conforto térmico para seu cão ou gato. Frete grátis acima de R$199." 
        />
        <meta name="keywords" content="tapete térmico pet, tapete aquecido cachorro, tapete gato, conforto pet, termopet" />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />
        <CartDrawer />
        
        <main className="flex-1">
          <HeroSection />
          <ProductsSection />
          <BenefitsSection />
          <CtaSection />
          <TestimonialsSection />
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Index;
