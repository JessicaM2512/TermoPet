import { useParams, Link } from "react-router-dom";
import { products } from "@/data/products";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { Helmet } from "react-helmet-async";
import { 
  ShoppingCart, 
  Heart, 
  Star, 
  Truck, 
  Shield, 
  RotateCcw,
  ChevronRight,
  Minus,
  Plus,
  Check
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const ProductDetail = () => {
  const { id } = useParams();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  const product = products.find((p) => p.id === id);
  const relatedProducts = products
    .filter((p) => p.id !== id && p.category === product?.category)
    .slice(0, 4);

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Produto não encontrado</h1>
            <Button asChild>
              <Link to="/produtos">Ver todos os produtos</Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
  };

  return (
    <>
      <Helmet>
        <title>{product.name} | Termopet</title>
        <meta name="description" content={product.description} />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />
        <CartDrawer />

        <main className="flex-1">
          {/* Breadcrumb */}
          <div className="border-b border-border">
            <div className="container py-4">
              <nav className="flex items-center gap-2 text-sm text-muted-foreground">
                <Link to="/" className="hover:text-foreground transition-colors">
                  Início
                </Link>
                <ChevronRight className="h-4 w-4" />
                <Link to="/produtos" className="hover:text-foreground transition-colors">
                  Produtos
                </Link>
                <ChevronRight className="h-4 w-4" />
                <span className="text-foreground">{product.name}</span>
              </nav>
            </div>
          </div>

          {/* Product Detail */}
          <section className="py-10">
            <div className="container">
              <div className="grid lg:grid-cols-2 gap-10">
                {/* Images */}
                <div className="space-y-4">
                  <div className="relative aspect-square rounded-2xl overflow-hidden bg-muted">
                    {discount > 0 && (
                      <span className="absolute top-4 left-4 z-10 px-3 py-1.5 bg-primary text-primary-foreground text-sm font-bold rounded-lg">
                        -{discount}%
                      </span>
                    )}
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="grid grid-cols-4 gap-3">
                    {[1, 2, 3, 4].map((i) => (
                      <div
                        key={i}
                        className={cn(
                          "aspect-square rounded-xl overflow-hidden bg-muted cursor-pointer border-2 transition-all",
                          i === 1 ? "border-primary" : "border-transparent hover:border-primary/50"
                        )}
                      >
                        <img
                          src={product.image}
                          alt={`${product.name} ${i}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Info */}
                <div>
                  {product.badge && (
                    <span className="inline-block px-3 py-1 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
                      {product.badge}
                    </span>
                  )}

                  <h1 className="text-3xl lg:text-4xl font-bold font-display mb-4">
                    {product.name}
                  </h1>

                  {/* Rating */}
                  <div className="flex items-center gap-3 mb-6">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={cn(
                            "h-5 w-5",
                            i < Math.floor(product.rating)
                              ? "fill-primary text-primary"
                              : "fill-muted text-muted"
                          )}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {product.rating} ({product.reviews} avaliações)
                    </span>
                  </div>

                  {/* Price */}
                  <div className="flex items-end gap-3 mb-6">
                    {product.originalPrice && (
                      <span className="text-xl text-muted-foreground line-through">
                        R$ {product.originalPrice.toFixed(2).replace(".", ",")}
                      </span>
                    )}
                    <span className="text-4xl font-bold text-primary">
                      R$ {product.price.toFixed(2).replace(".", ",")}
                    </span>
                  </div>

                  <p className="text-muted-foreground mb-6">
                    {product.description}
                  </p>

                  {/* Size */}
                  <div className="mb-6">
                    <p className="font-medium mb-2">Tamanho: <span className="text-primary">{product.size}</span></p>
                    <div className="flex gap-2">
                      {["PP", "P", "M", "G", "GG"].map((size) => (
                        <button
                          key={size}
                          className={cn(
                            "w-12 h-12 rounded-lg border-2 font-medium transition-all",
                            product.size.startsWith(size)
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:border-primary/50"
                          )}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Quantity */}
                  <div className="flex items-center gap-4 mb-6">
                    <span className="font-medium">Quantidade:</span>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="w-12 text-center font-semibold">{quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setQuantity(quantity + 1)}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3 mb-8">
                    <Button 
                      variant="hero" 
                      size="xl" 
                      className="flex-1"
                      onClick={handleAddToCart}
                    >
                      <ShoppingCart className="mr-2 h-5 w-5" />
                      Adicionar ao Carrinho
                    </Button>
                    <Button variant="outline" size="xl">
                      <Heart className="h-5 w-5" />
                    </Button>
                  </div>

                  {/* Benefits */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-muted/50">
                    <div className="flex items-center gap-3">
                      <Truck className="h-5 w-5 text-primary shrink-0" />
                      <div className="text-sm">
                        <p className="font-medium">Frete Grátis</p>
                        <p className="text-muted-foreground">Acima de R$199</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-secondary shrink-0" />
                      <div className="text-sm">
                        <p className="font-medium">Garantia</p>
                        <p className="text-muted-foreground">1 ano</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <RotateCcw className="h-5 w-5 text-primary shrink-0" />
                      <div className="text-sm">
                        <p className="font-medium">Troca Fácil</p>
                        <p className="text-muted-foreground">7 dias</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Features */}
          <section className="py-10 bg-muted/30">
            <div className="container">
              <h2 className="text-2xl font-bold font-display mb-6">Características</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  "Auto-aquecimento natural",
                  "Material hipoalergênico",
                  "Lavável na máquina",
                  "Sem eletricidade",
                  "Tecido premium",
                  "Base antiderrapante",
                  "Bordas reforçadas",
                  "Ecologicamente correto",
                ].map((feature, i) => (
                  <div key={i} className="flex items-center gap-3 p-4 rounded-xl bg-card">
                    <Check className="h-5 w-5 text-secondary shrink-0" />
                    <span className="text-sm font-medium">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <section className="py-16">
              <div className="container">
                <h2 className="text-2xl font-bold font-display mb-8">
                  Produtos Relacionados
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {relatedProducts.map((p) => (
                    <ProductCard key={p.id} product={p} />
                  ))}
                </div>
              </div>
            </section>
          )}
        </main>

        <Footer />
      </div>
    </>
  );
};

export default ProductDetail;
