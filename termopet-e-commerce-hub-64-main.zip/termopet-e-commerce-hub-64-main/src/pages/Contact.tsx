import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CartDrawer from "@/components/CartDrawer";
import { Button } from "@/components/ui/button";
import { Helmet } from "react-helmet-async";
import { Mail, Phone, MapPin, Clock, Send, MessageCircle } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Mensagem enviada!",
      description: "Entraremos em contato em breve.",
    });
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  return (
    <>
      <Helmet>
        <title>Contato | Termopet - Fale Conosco</title>
        <meta 
          name="description" 
          content="Entre em contato com a Termopet. Estamos prontos para ajudar com dúvidas sobre tapetes térmicos para pets." 
        />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />
        <CartDrawer />

        <main className="flex-1">
          {/* Hero */}
          <section className="bg-gradient-to-br from-background via-accent/30 to-background py-12">
            <div className="container text-center">
              <h1 className="text-3xl lg:text-4xl font-bold font-display mb-4">
                Fale <span className="text-primary">Conosco</span>
              </h1>
              <p className="text-muted-foreground max-w-xl mx-auto">
                Estamos aqui para ajudar! Tire suas dúvidas sobre nossos produtos ou faça um pedido especial.
              </p>
            </div>
          </section>

          {/* Contact Content */}
          <section className="py-16">
            <div className="container">
              <div className="grid lg:grid-cols-3 gap-8">
                {/* Contact Info */}
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold font-display mb-6">Informações</h2>
                  
                  {[
                    {
                      icon: Mail,
                      title: "Email",
                      info: "contato@termopet.com.br",
                      desc: "Respondemos em até 24h"
                    },
                    {
                      icon: Phone,
                      title: "Telefone",
                      info: "(11) 99999-9999",
                      desc: "WhatsApp disponível"
                    },
                    {
                      icon: MapPin,
                      title: "Endereço",
                      info: "São Paulo, SP",
                      desc: "Brasil"
                    },
                    {
                      icon: Clock,
                      title: "Horário",
                      info: "Seg - Sex: 9h às 18h",
                      desc: "Sábado: 9h às 13h"
                    }
                  ].map((item, index) => (
                    <div key={index} className="flex gap-4 p-4 rounded-xl bg-muted/50">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                        <item.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold">{item.title}</p>
                        <p className="text-primary">{item.info}</p>
                        <p className="text-sm text-muted-foreground">{item.desc}</p>
                      </div>
                    </div>
                  ))}

                  <Button variant="secondaryCta" size="lg" className="w-full">
                    <MessageCircle className="mr-2 h-5 w-5" />
                    Iniciar Chat no WhatsApp
                  </Button>
                </div>

                {/* Contact Form */}
                <div className="lg:col-span-2">
                  <div className="bg-card rounded-2xl p-6 lg:p-8 shadow-card">
                    <h2 className="text-2xl font-bold font-display mb-6">Envie uma Mensagem</h2>
                    
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Nome</label>
                          <input
                            type="text"
                            value={formData.name}
                            onChange={(e) => setFormData({...formData, name: e.target.value})}
                            className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                            placeholder="Seu nome"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Email</label>
                          <input
                            type="email"
                            value={formData.email}
                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                            className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                            placeholder="seu@email.com"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Assunto</label>
                        <select
                          value={formData.subject}
                          onChange={(e) => setFormData({...formData, subject: e.target.value})}
                          className="w-full h-11 px-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                          required
                        >
                          <option value="">Selecione um assunto</option>
                          <option value="duvida">Dúvida sobre produto</option>
                          <option value="pedido">Informações sobre pedido</option>
                          <option value="troca">Troca ou devolução</option>
                          <option value="parceria">Parceria comercial</option>
                          <option value="outro">Outro</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Mensagem</label>
                        <textarea
                          value={formData.message}
                          onChange={(e) => setFormData({...formData, message: e.target.value})}
                          rows={5}
                          className="w-full p-4 rounded-lg border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 resize-none"
                          placeholder="Como podemos ajudar?"
                          required
                        />
                      </div>

                      <Button variant="hero" size="lg" type="submit" className="w-full">
                        <Send className="mr-2 h-5 w-5" />
                        Enviar Mensagem
                      </Button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* FAQ Preview */}
          <section className="py-16 bg-muted/30">
            <div className="container">
              <div className="text-center mb-10">
                <h2 className="text-2xl font-bold font-display mb-4">Dúvidas Frequentes</h2>
                <p className="text-muted-foreground">Confira as perguntas mais comuns dos nossos clientes</p>
              </div>

              <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto">
                {[
                  {
                    q: "Como funciona o tapete térmico?",
                    a: "Nossos tapetes utilizam tecnologia de reflexão do calor corporal do pet, sem necessidade de eletricidade."
                  },
                  {
                    q: "É seguro para filhotes?",
                    a: "Sim! Por não usar eletricidade, é 100% seguro para pets de qualquer idade."
                  },
                  {
                    q: "Posso lavar o tapete?",
                    a: "Sim, todos os nossos tapetes são laváveis em máquina em ciclo delicado."
                  },
                  {
                    q: "Qual prazo de entrega?",
                    a: "Enviamos em até 2 dias úteis. O prazo varia conforme a região."
                  }
                ].map((faq, index) => (
                  <div key={index} className="p-5 rounded-xl bg-card">
                    <p className="font-semibold mb-2">{faq.q}</p>
                    <p className="text-sm text-muted-foreground">{faq.a}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Contact;
