import productImage1 from "@/assets/product-tapete-1.jpg";
import productImage2 from "@/assets/product-tapete-2.jpg";
import productImage3 from "@/assets/product-tapete-3.jpg";

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  size: string;
  rating: number;
  reviews: number;
  inStock: boolean;
  featured?: boolean;
  isOffer?: boolean;
  badge?: string;
}

export const products: Product[] = [
  {
    id: "1",
    name: "Tapete Térmico Classic",
    description: "Tapete térmico auto-aquecido para pets de pequeno porte. Ideal para gatos e cães pequenos.",
    price: 89.90,
    originalPrice: 119.90,
    image: productImage1,
    category: "pequeno",
    size: "P - 40x50cm",
    rating: 4.8,
    reviews: 324,
    inStock: true,
    featured: true,
    isOffer: true,
    badge: "Mais Vendido"
  },
  {
    id: "2",
    name: "Tapete Térmico Premium",
    description: "Modelo premium com camada extra de isolamento térmico. Perfeito para noites frias.",
    price: 149.90,
    originalPrice: 189.90,
    image: productImage2,
    category: "medio",
    size: "M - 60x80cm",
    rating: 4.9,
    reviews: 256,
    inStock: true,
    featured: true,
    isOffer: true,
    badge: "Premium"
  },
  {
    id: "3",
    name: "Tapete Térmico Family",
    description: "Tamanho família para pets grandes ou múltiplos pets. Aquecimento uniforme em toda superfície.",
    price: 199.90,
    originalPrice: 259.90,
    image: productImage3,
    category: "grande",
    size: "G - 80x100cm",
    rating: 4.7,
    reviews: 189,
    inStock: true,
    featured: true,
    isOffer: true,
    badge: "Família"
  },
  {
    id: "4",
    name: "Tapete Térmico Luxo",
    description: "Linha luxo com tecido impermeável e lavável. Design elegante para combinar com sua decoração.",
    price: 279.90,
    originalPrice: 349.90,
    image: productImage1,
    category: "grande",
    size: "GG - 100x120cm",
    rating: 5.0,
    reviews: 98,
    inStock: true,
    featured: false,
    isOffer: true,
    badge: "Luxo"
  },
  {
    id: "5",
    name: "Tapete Térmico Filhote",
    description: "Especialmente desenvolvido para filhotes. Temperatura controlada e material hipoalergênico.",
    price: 79.90,
    image: productImage1,
    category: "pequeno",
    size: "PP - 30x40cm",
    rating: 4.6,
    reviews: 145,
    inStock: true,
    featured: false,
    badge: "Filhotes"
  },
  {
    id: "6",
    name: "Tapete Térmico Outdoor",
    description: "Resistente a intempéries, ideal para casinhas externas. Material durável e impermeável.",
    price: 169.90,
    image: productImage2,
    category: "medio",
    size: "M - 60x80cm",
    rating: 4.5,
    reviews: 87,
    inStock: true,
    featured: false
  }
];

export const testimonials = [
  {
    id: "1",
    name: "Maria Silva",
    avatar: productImage1,
    rating: 5,
    comment: "Meu cachorro adora! Ele não sai mais de cima do tapete. Recomendo demais!",
    pet: "Thor - Golden Retriever"
  },
  {
    id: "2",
    name: "João Santos",
    avatar: productImage2,
    rating: 5,
    comment: "Qualidade excepcional. Minha gata idosa ficou muito mais confortável no inverno.",
    pet: "Luna - Persa"
  },
  {
    id: "3",
    name: "Ana Oliveira",
    avatar: productImage3,
    rating: 5,
    comment: "Comprei dois e valeu cada centavo. Entrega rápida e produto excelente!",
    pet: "Bob e Nina - SRD"
  },
  {
    id: "4",
    name: "Carlos Mendes",
    avatar: productImage1,
    rating: 4,
    comment: "Muito bom! O tapete aquece rapidinho e meu pet ficou mais calmo à noite.",
    pet: "Max - Bulldog"
  }
];

export const benefits = [
  {
    icon: "thermometer",
    title: "Auto-Aquecimento",
    description: "Tecnologia que reflete o calor corporal do seu pet"
  },
  {
    icon: "shield",
    title: "100% Seguro",
    description: "Sem fios, sem eletricidade, sem riscos"
  },
  {
    icon: "droplets",
    title: "Lavável",
    description: "Fácil de limpar, pode ser lavado na máquina"
  },
  {
    icon: "heart",
    title: "Confortável",
    description: "Material macio e acolhedor para seu pet"
  },
  {
    icon: "clock",
    title: "Durável",
    description: "Feito para durar anos com garantia estendida"
  },
  {
    icon: "leaf",
    title: "Ecológico",
    description: "Materiais sustentáveis e eco-friendly"
  }
];
