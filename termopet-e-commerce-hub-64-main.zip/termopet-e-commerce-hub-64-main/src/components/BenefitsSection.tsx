import { Thermometer, Shield, Droplets, Heart, Clock, Leaf } from "lucide-react";
import { cn } from "@/lib/utils";

const benefits = [
  {
    icon: Thermometer,
    title: "Auto-Aquecimento",
    description: "Tecnologia que reflete o calor corporal do seu pet",
    color: "text-primary",
    bgColor: "bg-primary/10"
  },
  {
    icon: Shield,
    title: "100% Seguro",
    description: "Sem fios, sem eletricidade, sem riscos",
    color: "text-secondary",
    bgColor: "bg-secondary/10"
  },
  {
    icon: Droplets,
    title: "Lavável",
    description: "Fácil de limpar, pode ser lavado na máquina",
    color: "text-primary",
    bgColor: "bg-primary/10"
  },
  {
    icon: Heart,
    title: "Confortável",
    description: "Material macio e acolhedor para seu pet",
    color: "text-secondary",
    bgColor: "bg-secondary/10"
  },
  {
    icon: Clock,
    title: "Durável",
    description: "Feito para durar anos com garantia estendida",
    color: "text-primary",
    bgColor: "bg-primary/10"
  },
  {
    icon: Leaf,
    title: "Ecológico",
    description: "Materiais sustentáveis e eco-friendly",
    color: "text-secondary",
    bgColor: "bg-secondary/10"
  }
];

const BenefitsSection = () => {
  return (
    <section className="py-16 lg:py-24 bg-muted/30">
      <div className="container">
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
            Por que escolher Termopet?
          </span>
          <h2 className="text-3xl lg:text-4xl font-bold font-display mb-4">
            Benefícios dos Nossos Tapetes
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Desenvolvidos com tecnologia de ponta para garantir o máximo conforto e segurança para seu pet
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className={cn(
                "group p-6 rounded-2xl bg-card shadow-card hover:shadow-hover transition-all duration-300 animate-fade-in",
                "hover:-translate-y-1"
              )}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className={cn(
                "w-14 h-14 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110",
                benefit.bgColor
              )}>
                <benefit.icon className={cn("h-7 w-7", benefit.color)} />
              </div>
              <h3 className="text-lg font-semibold font-display mb-2">
                {benefit.title}
              </h3>
              <p className="text-muted-foreground text-sm">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
