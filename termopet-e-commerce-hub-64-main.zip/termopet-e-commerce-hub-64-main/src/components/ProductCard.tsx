import { Product } from "@/data/products";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { ShoppingCart, Heart, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

interface ProductCardProps {
  product: Product;
  className?: string;
  style?: React.CSSProperties;
}

const ProductCard = ({ product, className, style }: ProductCardProps) => {
  const { addToCart } = useCart();

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div 
      className={cn(
        "group relative bg-card rounded-2xl overflow-hidden shadow-card hover:shadow-lg transition-all duration-300 animate-fade-in",
        className
      )}
      style={style}
    >
      {/* Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
        {discount > 0 && (
          <span className="px-2.5 py-1 bg-primary text-primary-foreground text-xs font-bold rounded-lg">
            -{discount}%
          </span>
        )}
        {product.badge && (
          <span className="px-2.5 py-1 bg-secondary text-secondary-foreground text-xs font-bold rounded-lg">
            {product.badge}
          </span>
        )}
      </div>

      {/* Wishlist button */}
      <button className="absolute top-3 right-3 z-10 w-9 h-9 rounded-full bg-card/80 backdrop-blur flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all hover:bg-primary hover:text-primary-foreground">
        <Heart className="h-4 w-4" />
      </button>

      {/* Image */}
      <Link to={`/produto/${product.id}`} className="block">
        <div className="aspect-square overflow-hidden bg-muted">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
        </div>
      </Link>

      {/* Content */}
      <div className="p-4">
        <Link to={`/produto/${product.id}`}>
          <h3 className="font-semibold text-card-foreground mb-1 group-hover:text-primary transition-colors line-clamp-1">
            {product.name}
          </h3>
        </Link>

        <p className="text-sm text-muted-foreground mb-2">{product.size}</p>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-3">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={cn(
                  "h-3.5 w-3.5",
                  i < Math.floor(product.rating)
                    ? "fill-primary text-primary"
                    : "fill-muted text-muted"
                )}
              />
            ))}
          </div>
          <span className="text-xs text-muted-foreground">
            ({product.reviews})
          </span>
        </div>

        {/* Price */}
        <div className="flex items-end justify-between">
          <div>
            {product.originalPrice && (
              <p className="text-sm text-muted-foreground line-through">
                R$ {product.originalPrice.toFixed(2).replace(".", ",")}
              </p>
            )}
            <p className="text-xl font-bold text-primary">
              R$ {product.price.toFixed(2).replace(".", ",")}
            </p>
          </div>
          <Button
            variant="cta"
            size="icon"
            onClick={() => addToCart(product)}
            className="shrink-0"
          >
            <ShoppingCart className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
