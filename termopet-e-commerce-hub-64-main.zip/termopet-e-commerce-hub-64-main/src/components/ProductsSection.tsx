import { products } from "@/data/products";
import ProductCard from "./ProductCard";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const ProductsSection = () => {
  const featuredProducts = products.filter((p) => p.featured).slice(0, 3);

  return (
    <section className="py-16 lg:py-24">
      <div className="container">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 mb-10">
          <div>
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Mais Vendidos
            </span>
            <h2 className="text-3xl lg:text-4xl font-bold font-display">
              Produtos em Destaque
            </h2>
          </div>
          <Button variant="ghost" asChild className="group">
            <Link to="/produtos">
              Ver todos os produtos
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredProducts.map((product, index) => (
            <ProductCard 
              key={product.id} 
              product={product}
              className={`animate-slide-up`}
              style={{ animationDelay: `${index * 100}ms` } as React.CSSProperties}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductsSection;
