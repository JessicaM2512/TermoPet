import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, PawPrint } from "lucide-react";

const CtaSection = () => {
  return (
    <section className="py-16 lg:py-24">
      <div className="container">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-hero p-8 lg:p-16">
          {/* Background decorations */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-background/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-background/10 rounded-full blur-3xl" />
          
          {/* Floating paws */}
          <PawPrint className="absolute top-8 left-8 h-12 w-12 text-background/10 animate-float" />
          <PawPrint className="absolute bottom-8 right-8 h-16 w-16 text-background/10 animate-float" style={{ animationDelay: "1s" }} />
          <PawPrint className="absolute top-1/2 right-1/4 h-8 w-8 text-background/10 animate-float" style={{ animationDelay: "0.5s" }} />

          <div className="relative z-10 text-center max-w-2xl mx-auto">
            <span className="inline-block px-4 py-1.5 rounded-full bg-background/20 text-primary-foreground text-sm font-medium mb-6">
              Oferta por tempo limitado
            </span>
            
            <h2 className="text-3xl lg:text-5xl font-bold font-display text-primary-foreground mb-6">
              Ofertas Especiais de Dezembro
            </h2>
            
            <p className="text-lg text-primary-foreground/80 mb-8">
              Aproveite até 30% de desconto em toda a linha de tapetes térmicos. 
              Seu pet merece o melhor conforto neste inverno!
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="xl" 
                className="bg-background text-primary hover:bg-background/90 shadow-soft"
                asChild
              >
                <Link to="/ofertas">
                  Ver Ofertas
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button 
                variant="outline" 
                size="xl"
                className="border-2 border-background/30 text-primary-foreground hover:bg-background/10"
                asChild
              >
                <Link to="/produtos">Todos os Produtos</Link>
              </Button>
            </div>

            {/* Countdown */}
            <div className="mt-10 flex items-center justify-center gap-4">
              <p className="text-primary-foreground/70 text-sm">Oferta termina em:</p>
              <div className="flex gap-2">
                {[
                  { value: "05", label: "dias" },
                  { value: "12", label: "horas" },
                  { value: "36", label: "min" },
                ].map((item, index) => (
                  <div key={index} className="bg-background/20 rounded-lg px-3 py-2 text-center">
                    <p className="text-xl font-bold text-primary-foreground">{item.value}</p>
                    <p className="text-xs text-primary-foreground/70">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;
