import { Link } from "react-router-dom";
import { 
  PawPrint, 
  Mail, 
  Phone, 
  MapPin, 
  Instagram, 
  Facebook, 
  MessageCircle,
  CreditCard,
  Shield,
  Truck
} from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-foreground text-background">
      {/* Trust badges */}
      <div className="border-b border-background/10">
        <div className="container py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center justify-center gap-4 p-4 rounded-xl bg-background/5">
              <Truck className="h-10 w-10 text-primary" />
              <div>
                <p className="font-semibold">Frete Grátis</p>
                <p className="text-sm text-background/70">Compras acima de R$ 199</p>
              </div>
            </div>
            <div className="flex items-center justify-center gap-4 p-4 rounded-xl bg-background/5">
              <Shield className="h-10 w-10 text-secondary" />
              <div>
                <p className="font-semibold">Compra Segura</p>
                <p className="text-sm text-background/70">Seus dados protegidos</p>
              </div>
            </div>
            <div className="flex items-center justify-center gap-4 p-4 rounded-xl bg-background/5">
              <CreditCard className="h-10 w-10 text-primary" />
              <div>
                <p className="font-semibold">Parcele em 12x</p>
                <p className="text-sm text-background/70">Sem juros no cartão</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-cta flex items-center justify-center">
                <PawPrint className="h-6 w-6 text-primary-foreground" />
              </div>
              <span className="text-2xl font-bold font-display">
                Termo<span className="text-primary">pet</span>
              </span>
            </Link>
            <p className="text-background/70 mb-4">
              Conforto térmico para seu melhor amigo. Tapetes auto-aquecidos de alta qualidade.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 rounded-lg bg-background/10 flex items-center justify-center hover:bg-primary transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-lg bg-background/10 flex items-center justify-center hover:bg-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-lg bg-background/10 flex items-center justify-center hover:bg-secondary transition-colors">
                <MessageCircle className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-semibold text-lg mb-4 font-display">Links Rápidos</h4>
            <ul className="space-y-2">
              {[
                { label: "Início", href: "/" },
                { label: "Produtos", href: "/produtos" },
                { label: "Ofertas", href: "/ofertas" },
                { label: "Sobre Nós", href: "/sobre" },
                { label: "Blog", href: "/blog" },
              ].map((link) => (
                <li key={link.href}>
                  <Link 
                    to={link.href}
                    className="text-background/70 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Help */}
          <div>
            <h4 className="font-semibold text-lg mb-4 font-display">Ajuda</h4>
            <ul className="space-y-2">
              {[
                { label: "FAQ", href: "/faq" },
                { label: "Trocas e Devoluções", href: "/trocas" },
                { label: "Política de Privacidade", href: "/privacidade" },
                { label: "Termos de Uso", href: "/termos" },
                { label: "Rastrear Pedido", href: "/rastrear" },
              ].map((link) => (
                <li key={link.href}>
                  <Link 
                    to={link.href}
                    className="text-background/70 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-lg mb-4 font-display">Contato</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-background/70">
                <Mail className="h-5 w-5 text-primary" />
                <span>contato@termopet.com.br</span>
              </li>
              <li className="flex items-center gap-3 text-background/70">
                <Phone className="h-5 w-5 text-primary" />
                <span>(11) 99999-9999</span>
              </li>
              <li className="flex items-start gap-3 text-background/70">
                <MapPin className="h-5 w-5 text-primary shrink-0" />
                <span>São Paulo, SP - Brasil</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-background/10">
        <div className="container py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-background/60 text-sm">
            © 2024 Termopet. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-4">
            <img src="/placeholder.svg" alt="Visa" className="h-8 w-auto opacity-60" />
            <img src="/placeholder.svg" alt="Mastercard" className="h-8 w-auto opacity-60" />
            <img src="/placeholder.svg" alt="PIX" className="h-8 w-auto opacity-60" />
            <img src="/placeholder.svg" alt="Boleto" className="h-8 w-auto opacity-60" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
